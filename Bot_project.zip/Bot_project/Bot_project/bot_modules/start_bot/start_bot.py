import aiogram
import bot_modules.create_dispatcher.dispatcher as m_dispather
import aiogram.filters as a_filters
import bot_modules.create_keyboard.keyboard as m_keyboard

@m_dispather.dispatcher.message(a_filters.CommandStart())
async def start_bot(message: aiogram.types.Message):
    await message.answer(text = 'Вітаю. Оберіть вашу роль:', reply_markup = m_keyboard.keyboard)
