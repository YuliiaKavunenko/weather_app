import aiogram 
import bot_modules.create_bot.bot as bot 
import bot_modules.create_dispatcher.dispatcher as dp 
import bot_modules.create_keyboard.keyboard as kb
import aiogram.filters as ft

products = {}
state = {}

print('wlenfwn')
@dp.dispatcher.message(ft.Command('add_message'))
async def command_add_message(message: aiogram.types.Message):
    user_id = message.from_user.id
    print('create message')
    await message.answer(chat_id = user_id,text = 'Надішліть назву продукту😀😀😀😀😀😀😀')
    state[user_id] = 'name'


@dp.dispatcher.message()
async def edit_message(message: aiogram.types.Message):
    user_id = message.from_user.id
    if state.get(user_id) == 'name':
        products['name'] = message.text
        await message.answer('Надішліть фото продукту🫵🫵🫵🫵🫵🫵', reply_markup = kb.clear_keyboard)
        state[user_id] = 'photo'
    elif state.get(user_id) == 'photo' and message.content_type == 'photo':
        products['photo_id'] = message.photo[-1].file_id
        await message.answer('Надішліть інформацію про продукт🫵🫵🫵🫵🫵🫵', reply_markup = kb.clear_keyboard)
        state[user_id] = 'info'
    elif state.get(user_id) == 'info':
        products['info'] = message.text
        # products[['name']] = {'info': message.text}
        await message.answer('ПРОДУКТ ДОДАНО!!!!!!!!:D')
        state[user_id] = 'end'




        

        
    






















