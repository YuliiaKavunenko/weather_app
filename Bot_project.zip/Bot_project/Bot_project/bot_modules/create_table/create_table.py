import sqlite3

def create_db():
    connect = sqlite3.connect("database.db")
    cursor = connect.cursor()
    

    cursor.execute("CREATE TABLE IF NOT EXISTS Admins(email TEXT, nickname TEXT, password TEXT, phone_number TEXT)")
    connect.commit()
    connect.close()

create_db()