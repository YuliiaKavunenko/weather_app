import aiogram
import sqlite3
import bot_modules.create_dispatcher.dispatcher as c_dispatcher
import bot_modules.create_keyboard.keyboard as c_keyboard
import bot_modules.create_table.create_table as c_table
import bot_modules.create_bot.bot as c_bot


user_state = {}#для перевірки стану
data = {}
temporary_data ={}

@c_dispatcher.dispatcher.message()

async def message_handler(message:aiogram.types.Message):
    global user_state
    global user_id
    user_id = message.from_user.id#для знаходження id користувача(чата)
    email = ''
    nickname = ''
    password = ''
    phone_number = ''

    if message.text == "Адміністратор":
        await message.answer(text = "Оберіть наступну дію:", reply_markup = c_keyboard.new_keyboard)

    if message.text == "Клієнт":
        await message.answer(text = "Оберіть наступну дію:", reply_markup = c_keyboard.new_keyboard)

    if message.text == "Реєстрація":#EMAIL
        await message.answer ("Введіть email:", reply_markup = c_keyboard.clear_keyboard)
        user_state[user_id] = 'email'

    elif user_state.get(user_id) == 'email':#NICKNAME
        # email = message.text
        data['email'] = message.text
        await message.answer("Введіть ім'я:", reply_markup = c_keyboard.clear_keyboard)
        user_state[user_id] = 'nickname'
        
    elif user_state.get(user_id) == 'nickname':#PASSWORD
        # nickname = message.text
        data['nickname'] = message.text
        await message.answer("Введіть пароль:", reply_markup = c_keyboard.clear_keyboard)
        user_state[user_id] = 'password'

    elif user_state.get(user_id) == 'password':#PHONE NUMBER
        # password = message.text
        data['password'] = message.text
        await message.answer("Введіть номер телефона:", reply_markup = c_keyboard.clear_keyboard)
        user_state[user_id] = 'phone_number'

    elif user_state.get(user_id) == 'phone_number':#End
        # phone_number = message.text
        data['phone_number'] = message.text
        await message.answer(text = "Дякую за реєстрацію. Очікуйте на підтвердження.", reply_markup = c_keyboard.clear_keyboard)
        user_state[user_id] = 'end'
        temporary_data[user_id]=data
        moderator_id = 1734010755
        await c_bot.bot.send_message(chat_id=moderator_id, text=f"Користувач {data["nickname"]} хоче зареєструватися. Підтвердити?", reply_markup=c_keyboard.moderator_keyboard)

        # con = sqlite3.connect("database.db")
        # cursor = con.cursor()
        # cursor.execute("INSERT INTO Admins (email, nickname, password, phone_number) VALUES (?,?,?,?)", (data['email'], data['nickname'], data['password'], data['phone_number']))
        # con.commit()

    # print(email)
    

        
        # print(email)
# @c_dispatcher.dispatcher.message()
# async def message_handler(message:aiogram.types.Message):
#     print("lasndljncjn")
#     email = message.text
#     print(email)