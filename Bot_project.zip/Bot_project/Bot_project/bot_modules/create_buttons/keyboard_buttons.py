import aiogram

button_klient = aiogram.types.KeyboardButton(text = "Клієнт")
button_admin = aiogram.types.KeyboardButton(text = "Адміністратор")

button_avt = aiogram.types.KeyboardButton(text = "Авторизація")
button_reg = aiogram.types.KeyboardButton(text = "Реєстрація")

button_info = aiogram.types.InlineKeyboardButton(text ="Інформація", callback_data="info")
button_confirmation = aiogram.types.InlineKeyboardButton(text = "Підтвердити", callback_data = "confirmation")
button_select = aiogram.types.InlineKeyboardButton(text="Обрати", callback_data="select")

button_confirm = aiogram.types.InlineKeyboardButton(text="Підтвердити", callback_data="accept")