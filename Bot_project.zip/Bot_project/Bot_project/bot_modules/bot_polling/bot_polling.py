import aiogram
import bot_modules.create_bot.bot as c_bot
import bot_modules.create_dispatcher.dispatcher as m_dispatcher

#async
async def main():
    await m_dispatcher.dispatcher.start_polling(c_bot.bot)