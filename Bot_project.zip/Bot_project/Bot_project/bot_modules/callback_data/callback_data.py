import sqlite3
import aiogram
import bot_modules.create_dispatcher.dispatcher as dispatcher    
import bot_modules.create_buttons.keyboard_buttons as m_buttons  
import bot_modules.create_keyboard.keyboard as our_keyboard      
import bot_modules.create_table.create_table as m_table          
import bot_modules.message_handler.message_handler as m_handler 
import bot_modules.create_bot.bot as m_bot

# print("callback")
@dispatcher.dispatcher.callback_query()
async def callback(callback: aiogram.types.CallbackQuery):
    if callback.data == "accept":
        # print("callback2")
        con = sqlite3.connect("database.db")
        cursor = con.cursor()
        cursor.execute("INSERT INTO Admins (email, nickname, password, phone_number) VALUES (?,?,?,?)", (m_handler.data['email'], m_handler.data['nickname'], m_handler.data['password'], m_handler.data['phone_number']))
        con.commit()
        await m_bot.bot.send_message(m_handler.user_id, "Успішно підтверджено")
        await m_bot.bot.send_message(chat_id=callback.from_user.id, text = "Успішно підтверджено")
        # print(f'{callback.from_user.id}')
        # print(f'{m_handler.user_id}')
        # else: 
        #     print('error')
        
