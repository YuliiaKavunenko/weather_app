import aiogram
import bot_modules

if __name__ == "__main__":
    aiogram._asyncio.run(bot_modules.main())


    